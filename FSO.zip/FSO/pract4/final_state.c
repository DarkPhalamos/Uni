/**range_process**/
#include <stdio.h>
#include <stdlib.h>

int main() {
pid_t val_return;
int status;
int final_state;
    for (int i = 1; i < 5; i++) {
        val_return = fork();
       if (val_return==0) {
        printf( "Fill creat en iteracio=%d\n", i);
        sleep(10);
        exit(i);}
        else
        {
            printf("Padre %ld, iteration %d\n", (long) getpid(), i);
            printf("Padre %ld, iteration %d\n", (long) val_return);
            break;
        }
        sleep(2);
    }
    int i =0;
    while(wait(&final_state)>0)
        {
            printf("Father %ld iteration %d", (long) getpid(), i);
            printf("My son said %d\n", WEXITSTATUS(final_state));
            
        }
        exit   (i);
}

