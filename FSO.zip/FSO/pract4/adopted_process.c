/**range_process**/
#include <stdio.h>
#include <stdlib.h>

int main() {
pid_t val_return;
    for (int i = 1; i < 6; i++) {
        val_return = fork();
       if (val_return==0) {
        printf( "Fill creat en iteracio=%d\n", i);
        sleep(20);
        exit(i);}
        sleep(2);
    }
    sleep(10);
    exit(0);
}

